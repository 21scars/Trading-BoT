import asyncio, functools, logging
from datetime import time as dtime, timezone

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

from core.strategies import STRATEGIES
from settings import MARKET_PROFILES, Env
from telegram_bot import commands as C

log = logging.getLogger("telegram")


def menu_keyboard():
    b = InlineKeyboardButton
    return InlineKeyboardMarkup([
        [b("📊 Status", callback_data="status"), b("💼 Positions", callback_data="positions")],
        [b("📈 Stats", callback_data="stats"), b("🧾 Trades", callback_data="trades")],
        [b("⏸ Pause", callback_data="pause"), b("▶️ Resume", callback_data="resume")],
        [b("🌍 Market", callback_data="market"), b("🎯 Strategy", callback_data="strategy")],
        [b("⚙️ Config", callback_data="config")],
        [b("🛑 Close all", callback_data="closeall")]])


def build_app(engine):
    cfg = engine.cfg

    async def reply(update, text, kb=None):
        await update.effective_message.reply_text(text, reply_markup=kb)

    def authorized(fn):
        @functools.wraps(fn)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
            chat = update.effective_chat
            if chat is None or chat.id not in Env.ALLOWED_CHAT_IDS:
                log.warning("Unauthorized access attempt from chat_id=%s", getattr(chat, "id", None))
                if update.effective_message:
                    await update.effective_message.reply_text(f"⛔ Not authorized. (chat id {getattr(chat, 'id', '?')})")
                return
            try:
                return await fn(update, context)
            except Exception as e:                           # never let a handler crash the bot
                log.exception("handler error")
                await reply(update, f"⚠️ {e}")
        return wrapper

    async def broadcast(bot, text):
        for cid in Env.ALLOWED_CHAT_IDS:
            try:
                await bot.send_message(cid, text)
            except Exception:
                log.exception("send failed to %s", cid)

    def strategy_keyboard():
        return InlineKeyboardMarkup([[InlineKeyboardButton(("✅ " if n == cfg.strategy else "") + n,
                                                           callback_data=f"strat:{n}")] for n in STRATEGIES])

    def market_keyboard():
        return InlineKeyboardMarkup([[InlineKeyboardButton(("✅ " if n == cfg.market else "") + n.title(),
                                                           callback_data=f"mkt:{n}") for n in MARKET_PROFILES]])

    def confirm_keyboard():
        return InlineKeyboardMarkup([[InlineKeyboardButton("✅ Yes, close all", callback_data="closeall_yes"),
                                      InlineKeyboardButton("Cancel", callback_data="closeall_no")]])

    # ---------------- command handlers ----------------
    @authorized
    async def start(u, c): await reply(u, C.HELP, menu_keyboard())
    @authorized
    async def menu(u, c): await reply(u, "Menu", menu_keyboard())
    @authorized
    async def status(u, c): await reply(u, C.status_text(engine))
    @authorized
    async def balance(u, c): await reply(u, C.balance_text(engine))
    @authorized
    async def positions(u, c): await reply(u, C.positions_text(engine))
    @authorized
    async def trades(u, c): await reply(u, C.trades_text(engine))
    @authorized
    async def stats(u, c): await reply(u, C.stats_text(engine))
    @authorized
    async def config(u, c): await reply(u, C.config_text(engine))

    @authorized
    async def pause(u, c):
        cfg.set("paused", "true"); await reply(u, "⏸ Paused. Open trades keep their SL/TP; no new trades.")

    @authorized
    async def resume(u, c):
        cfg.set("paused", "false"); await reply(u, "▶️ Trading resumed.")

    @authorized
    async def closeall(u, c): await reply(u, "Close ALL bot trades?", confirm_keyboard())

    @authorized
    async def close(u, c):
        if not c.args:
            return await reply(u, "Usage: /close EURUSD")
        n = await asyncio.to_thread(engine.close_symbol, c.args[0])
        await reply(u, f"Closed {n} trade(s) on {c.args[0]}." if n else f"No open bot trade on {c.args[0]}.")

    @authorized
    async def strategy(u, c):
        if c.args:
            return await reply(u, C.apply_setting(engine, "strategy", c.args[0]))
        await reply(u, "Choose a strategy:", strategy_keyboard())

    @authorized
    async def market(u, c):
        if not c.args:
            return await reply(u, f"Current market: {cfg.market.upper()} ({', '.join(cfg.symbols)})\nChoose:", market_keyboard())
        syms = " ".join(c.args[1:]).replace(",", " ").split() or None
        await reply(u, C.apply_market(engine, c.args[0], syms))

    @authorized
    async def find(u, c):
        if not c.args:
            return await reply(u, "Usage: /find btc   (searches your broker's symbol list)")
        await reply(u, C.find_text(engine, c.args[0]))

    def single(key):
        @authorized
        async def h(u, c):
            if not c.args:
                return await reply(u, f"Usage: /{key} <value>   (current: {cfg.d.get(key)})")
            await reply(u, C.apply_setting(engine, key, " ".join(c.args)))
        return h

    @authorized
    async def set_(u, c):
        if len(c.args) < 2:
            return await reply(u, "Usage: /set <name> <value>   e.g. /set rr 2")
        await reply(u, C.apply_setting(engine, c.args[0], " ".join(c.args[1:])))

    # ---------------- inline buttons ----------------
    @authorized
    async def buttons(u, c):
        q = u.callback_query
        await q.answer()
        d = q.data
        simple = {"status": C.status_text, "positions": C.positions_text, "stats": C.stats_text,
                  "trades": C.trades_text, "config": C.config_text}
        if d in simple:
            await reply(u, simple[d](engine))
        elif d == "pause":
            cfg.set("paused", "true"); await reply(u, "⏸ Paused.")
        elif d == "resume":
            cfg.set("paused", "false"); await reply(u, "▶️ Trading resumed.")
        elif d == "market":
            await reply(u, f"Current market: {cfg.market.upper()} ({', '.join(cfg.symbols)})\nChoose:", market_keyboard())
        elif d.startswith("mkt:"):
            await reply(u, C.apply_market(engine, d.split(":", 1)[1]))
        elif d == "strategy":
            await reply(u, "Choose a strategy:", strategy_keyboard())
        elif d.startswith("strat:"):
            await reply(u, C.apply_setting(engine, "strategy", d.split(":", 1)[1]))
        elif d == "closeall":
            await reply(u, "Close ALL bot trades?", confirm_keyboard())
        elif d == "closeall_yes":
            n = await asyncio.to_thread(engine.close_all)
            await reply(u, f"🛑 Closed {n} trade(s). Results follow in a few seconds.")
        elif d == "closeall_no":
            await reply(u, "Cancelled.")

    # ---------------- background jobs ----------------
    state = {"err": None}

    async def engine_job(context: ContextTypes.DEFAULT_TYPE):
        try:
            for m in await asyncio.to_thread(engine.tick):
                await broadcast(context.bot, m)
            state["err"] = None
        except Exception as e:
            log.exception("engine tick failed")
            if state["err"] != str(e):                       # alert once per distinct error
                state["err"] = str(e)
                await broadcast(context.bot, f"🚨 Engine error: {e}\nRetrying automatically.")

    async def summary_job(context: ContextTypes.DEFAULT_TYPE):
        await broadcast(context.bot, C.summary_text(engine))

    async def post_init(app: Application):
        a = engine.broker.account()
        await broadcast(app.bot, f"🟢 Bot online • {a['login']} {'DEMO' if a['is_demo'] else 'REAL'} • "
                                 f"{cfg.strategy} {cfg.timeframe} {','.join(cfg.symbols)}\nSend /help")

    async def on_error(update, context):
        log.error("Telegram error: %s", context.error)

    app = Application.builder().token(Env.TELEGRAM_TOKEN).post_init(post_init).build()
    for name, fn in [("start", start), ("help", start), ("menu", menu), ("status", status), ("balance", balance),
                     ("positions", positions), ("trades", trades), ("stats", stats), ("config", config),
                     ("pause", pause), ("resume", resume), ("closeall", closeall), ("close", close),
                     ("strategy", strategy), ("market", market), ("find", find), ("set", set_), ("risk", single("risk_pct")),
                     ("symbols", single("symbols")), ("timeframe", single("timeframe"))]:
        app.add_handler(CommandHandler(name, fn))
    app.add_handler(CallbackQueryHandler(buttons))
    app.add_error_handler(on_error)
    app.job_queue.run_repeating(engine_job, interval=Env.TICK_SECONDS, first=3)
    app.job_queue.run_daily(summary_job, time=dtime(Env.DAILY_SUMMARY_HOUR_UTC, 0, tzinfo=timezone.utc))
    return app
