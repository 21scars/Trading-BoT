"""Pure functions: engine/db -> text. Easy to test, no Telegram objects inside."""
from datetime import datetime, timedelta, timezone

from settings import MARKET_PROFILES

HELP = """🤖 MT5 Trading Bot

📊 Info
/status – account, bot state, settings
/balance – balance & equity
/positions – open trades
/trades – last 10 closed trades
/stats – today / 7 days / 30 days / all

▶️ Control
/pause – stop opening new trades
/resume – start trading again
/close EURUSD – close that symbol
/closeall – close every bot trade
/menu – button menu

🌍 Market
/market – choose Forex or Crypto (buttons)
/market crypto BTCUSD,ETHUSD – with your broker's names
/find btc – search your broker's symbols

⚙️ Settings (apply instantly)
/strategy [name]
/risk 0.5
/symbols EURUSD,GBPUSD
/timeframe M15
/set rr 2   (also: atr_sl_mult, breakeven_r, max_open_trades,
             max_daily_trades, max_daily_loss_pct, max_spread_points,
             max_spread_stop_pct)
/set hours 7-20   (UTC, or 'off')
/config – show all settings"""


def money(x, ccy=""):
    return f"{x:+,.2f} {ccy}".strip()


def balance_text(e):
    a = e.broker.account()
    return (f"💰 Balance {a['balance']:,.2f} {a['currency']}\nEquity {a['equity']:,.2f} • "
            f"Floating {a['profit']:+,.2f}\nFree margin {a['free_margin']:,.2f} • Leverage 1:{a['leverage']}")


def config_text(e):
    c = e.cfg
    hours = f"{c.trade_hours[0]}-{c.trade_hours[1]} UTC" if c.trade_hours else "24h"
    return (f"⚙️ Settings\nMarket: {c.market.upper()} • Strategy: {c.strategy}\nSymbols: {', '.join(c.symbols)} • TF {c.timeframe}\n"
            f"Risk {c.risk_pct}% • SL {c.atr_sl_mult}×ATR • RR {c.rr} • Breakeven at {c.breakeven_r}R\n"
            f"Max open {c.max_open_trades} • Max/day {c.max_daily_trades} • Daily loss limit {c.max_daily_loss_pct}%\n"
            f"Max spread {c.max_spread_points or 'off'} pts / {c.max_spread_stop_pct:.0f}% of stop • Hours {hours}")


def status_text(e):
    a, c = e.broker.account(), e.cfg
    mine = e.broker.positions(c.magic)
    today = e.db.stats(e.today_start())
    state = "⏸ PAUSED" if c.paused else "🟢 RUNNING"
    mode = "DEMO" if a["is_demo"] else ("REAL (enabled)" if e.env.ALLOW_LIVE else "REAL (trading blocked)")
    return (f"🤖 {state}\nAccount {a['login']} • {a['server']} • {mode}\n"
            f"Balance {a['balance']:,.2f} • Equity {a['equity']:,.2f} {a['currency']}\n"
            f"Open trades {len(mine)}/{c.max_open_trades} • Today {today['trades']} closed, "
            f"{money(today['pnl'], a['currency'])}\n\n" + config_text(e).split("\n", 1)[1])


def positions_text(e):
    mine = e.broker.positions(e.cfg.magic)
    if not mine:
        return "No open trades."
    return "💼 Open trades\n" + "\n".join(
        f"#{p['ticket']} {p['side'].upper()} {p['symbol']} {p['lots']} @ {p['entry']} • SL {p['sl']} TP {p['tp']} • "
        f"{p['profit']:+.2f}" for p in mine)


def trades_text(e, n=10):
    rows = e.db.recent_closed(n)
    if not rows:
        return "No closed trades yet."
    return "🧾 Last trades\n" + "\n".join(
        f"{'✅' if (r['profit'] or 0) >= 0 else '❌'} {r['symbol']} {r['side'].upper()} {r['lots']} • "
        f"{(r['profit'] or 0):+.2f} • {r['reason']} • {r['closed_at'][:16].replace('T', ' ')}" for r in rows)


def stats_text(e):
    now, ccy = e.now(), e.broker.account()["currency"]
    fmt = lambda d: d.strftime("%Y-%m-%dT%H:%M:%S")
    periods = [("Today", e.today_start()), ("7 days", fmt(now - timedelta(days=7))),
               ("30 days", fmt(now - timedelta(days=30))), ("All time", None)]
    lines = ["📈 Performance"]
    for name, since in periods:
        s = e.db.stats(since)
        pf = f"{s['profit_factor']:.2f}" if s["profit_factor"] else "-"
        lines.append(f"{name}: {s['trades']} trades • win {s['win_rate']:.0f}% • "
                     f"P/L {money(s['pnl'], ccy)} • PF {pf}")
    return "\n".join(lines)


def summary_text(e):
    s, a = e.db.stats(e.today_start()), e.broker.account()
    return (f"🌙 Daily summary\nTrades {s['trades']} • Wins {s['wins']} • Losses {s['losses']}\n"
            f"P/L {money(s['pnl'], a['currency'])}\nBalance {a['balance']:,.2f} • Equity {a['equity']:,.2f}")


def apply_setting(e, key, value):
    """Used by /set, /risk, /symbols, /timeframe, /strategy."""
    if key == "symbols":
        for s in value.replace(",", " ").split():
            e.broker.symbol_info(s)                       # raises if the broker doesn't have it
    msg = e.cfg.set(key, value)
    if key in ("timeframe", "symbols"):
        e.last_candle.clear()                              # don't trade on the first candle after a change
    return msg


def find_text(e, pattern):
    names = e.broker.find_symbols(pattern)
    if not names:
        return f"No symbols matching '{pattern}' at your broker."
    return "🔎 " + ", ".join(names) + "\n\nUse: /symbols NAME1,NAME2"


def apply_market(e, name, symbols=None):
    """Switch between market presets. Symbols default to the preset's, or pass your broker's exact names."""
    name = name.lower()
    if name not in MARKET_PROFILES:
        raise ValueError("Market must be: " + ", ".join(MARKET_PROFILES))
    wanted = symbols or MARKET_PROFILES[name]["symbols"]
    ok, missing = [], []
    for s in wanted:
        try:
            e.broker.symbol_info(s)
            ok.append(s)
        except Exception:
            missing.append(s)
    if not ok:
        hint = "BTC" if name == "crypto" else "EUR"
        raise ValueError(f"Your broker has no symbol named {', '.join(missing)}.\n"
                         f"Search with /find {hint}, then send e.g. /market {name} <exact names>")
    with e.lock:
        e.cfg.apply_market(name, ok)
        e.last_candle.clear()                              # don't trade on the first candle after a change
    note = f"\n⚠️ Not available at your broker, skipped: {', '.join(missing)}" if missing else ""
    return f"🌍 Market set to {name.upper()}: {', '.join(ok)}{note}\n\n" + config_text(e)
