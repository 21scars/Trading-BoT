"""Entry point:  python main.py"""
import logging, sys
from logging.handlers import RotatingFileHandler

from settings import Env, LOG_DIR, RuntimeConfig


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        handlers=[logging.StreamHandler(), RotatingFileHandler(LOG_DIR / "bot.log", maxBytes=2_000_000,
                                                                              backupCount=3, encoding="utf-8")])
    if not Env.TELEGRAM_TOKEN or not Env.ALLOWED_CHAT_IDS:
        sys.exit("Set TELEGRAM_TOKEN and TELEGRAM_CHAT_ID in .env (see README).")

    from core.engine import Engine
    from core.mt5_client import MT5Client, MT5Error
    from core.storage import Storage
    from telegram_bot.bot import build_app

    broker = MT5Client(Env)
    try:
        acct = broker.connect()
    except MT5Error as e:
        sys.exit(f"Could not connect to MetaTrader 5: {e}\nOpen the MT5 terminal, log in, then run again.")
    logging.info("Connected to MT5: %s @ %s (%s)", acct["login"], acct["server"], "DEMO" if acct["is_demo"] else "REAL")
    if not acct["is_demo"] and not Env.ALLOW_LIVE:
        logging.warning("REAL account detected: trading is blocked until ALLOW_LIVE=YES")

    engine = Engine(RuntimeConfig(Env.CONFIG_PATH), broker, Storage(Env.DB_PATH), Env)
    try:
        build_app(engine).run_polling()
    finally:
        broker.shutdown()


if __name__ == "__main__":
    main()
