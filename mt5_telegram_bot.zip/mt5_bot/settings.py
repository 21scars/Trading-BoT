"""Environment (.env) + runtime config (data/config.json, editable live from Telegram)."""
import json, threading
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass

DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
DATA_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

TIMEFRAMES = ["M1", "M5", "M15", "M30", "H1", "H4", "D1"]


def _ids(raw):
    return {int(x) for x in raw.replace(" ", "").split(",") if x.lstrip("-").isdigit()}


class Env:
    MT5_LOGIN = int(os.getenv("MT5_LOGIN", "0") or 0)
    MT5_PASSWORD = os.getenv("MT5_PASSWORD", "")
    MT5_SERVER = os.getenv("MT5_SERVER", "")
    MT5_PATH = os.getenv("MT5_PATH", "")                       # optional: full path to terminal64.exe
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
    ALLOWED_CHAT_IDS = _ids(os.getenv("TELEGRAM_CHAT_ID", ""))  # only these chats can control the bot
    ALLOW_LIVE = os.getenv("ALLOW_LIVE", "NO") == "YES"         # real-money accounts blocked unless YES
    DAILY_SUMMARY_HOUR_UTC = int(os.getenv("DAILY_SUMMARY_HOUR_UTC", "21"))
    TICK_SECONDS = int(os.getenv("TICK_SECONDS", "5"))
    DB_PATH = DATA_DIR / "trades.db"
    CONFIG_PATH = DATA_DIR / "config.json"


# One-tap presets. Crypto here means your broker's crypto CFDs on MT5 (e.g. BTCUSD), which trade 24/7.
MARKET_PROFILES = {
    "forex": {"symbols": ["EURUSD", "GBPUSD"], "timeframe": "M15", "risk_pct": 0.5, "atr_sl_mult": 1.5, "rr": 1.5,
              "max_spread_points": 30, "trade_hours": [7, 20]},
    "crypto": {"symbols": ["BTCUSD", "ETHUSD"], "timeframe": "M15", "risk_pct": 0.5, "atr_sl_mult": 2.0, "rr": 1.5,
               "max_spread_points": 0, "trade_hours": None},       # 0 = rely on the spread-vs-stop rule instead
}

DEFAULTS = {
    "market": "forex",
    "symbols": ["EURUSD", "GBPUSD"],
    "timeframe": "M15",
    "strategy": "engulfing",
    "risk_pct": 0.5,            # % of balance lost if the stop is hit
    "atr_period": 14,
    "atr_sl_mult": 1.5,         # stop = 1.5 x ATR
    "rr": 1.5,                  # take profit = 1.5 x stop distance
    "breakeven_r": 1.0,         # move SL to entry after +1R profit (0 = off)
    "max_open_trades": 2,
    "max_daily_trades": 6,
    "max_daily_loss_pct": 2.0,  # stop trading for the day after losing this much
    "max_spread_points": 30,    # skip signals when spread is wider (points); 0 = off
    "max_spread_stop_pct": 25.0,  # skip when spread is more than this % of the stop distance (works for any market)
    "trade_hours": [7, 20],     # UTC [start, end) or null for 24h
    "magic": 20260101,          # ID that marks this bot's trades
    "paused": False,
}

SCHEMA = {  # key: (type, min, max)
    "risk_pct": (float, 0.05, 5.0), "atr_period": (int, 2, 100), "atr_sl_mult": (float, 0.5, 10.0),
    "rr": (float, 0.5, 10.0), "breakeven_r": (float, 0.0, 10.0), "max_open_trades": (int, 1, 20),
    "max_daily_trades": (int, 1, 100), "max_daily_loss_pct": (float, 0.1, 20.0),
    "max_spread_points": (int, 0, 100000), "max_spread_stop_pct": (float, 1.0, 100.0),
}


class RuntimeConfig:
    def __init__(self, path):
        self.path = Path(path)
        self._lock = threading.RLock()
        self.d = dict(DEFAULTS)
        if self.path.exists():
            try:
                self.d.update(json.loads(self.path.read_text()))
            except Exception:
                pass
        self.save()

    def __getattr__(self, k):
        d = self.__dict__.get("d")
        if d is not None and k in d:
            return d[k]
        raise AttributeError(k)

    def apply_market(self, name, symbols):
        with self._lock:
            self.d.update({k: v for k, v in MARKET_PROFILES[name].items() if k != "symbols"})
            self.d["symbols"], self.d["market"] = list(symbols), name
            self.save()

    def save(self):
        self.path.write_text(json.dumps(self.d, indent=2))

    def set(self, key, raw):
        from core.strategies import STRATEGIES
        key, raw = key.lower(), str(raw).strip()
        with self._lock:
            if key in SCHEMA:
                typ, lo, hi = SCHEMA[key]
                v = typ(raw)
                if not lo <= v <= hi:
                    raise ValueError(f"{key} must be between {lo} and {hi}")
                self.d[key] = v
            elif key == "strategy":
                if raw not in STRATEGIES:
                    raise ValueError("Strategy must be one of: " + ", ".join(STRATEGIES))
                self.d[key] = raw
            elif key == "timeframe":
                if raw.upper() not in TIMEFRAMES:
                    raise ValueError("Timeframe must be one of: " + ", ".join(TIMEFRAMES))
                self.d[key] = raw.upper()
            elif key == "symbols":
                syms = [s for s in raw.replace(",", " ").split() if s]
                if not syms:
                    raise ValueError("Give at least one symbol, e.g. EURUSD,GBPUSD")
                self.d[key] = syms
            elif key in ("trade_hours", "hours"):
                key = "trade_hours"
                if raw.lower() in ("off", "none", "24h", "all"):
                    self.d[key] = None
                else:
                    a, b = [int(x) for x in raw.split("-")]
                    if not 0 <= a < b <= 24:
                        raise ValueError("Hours must look like 7-20 (UTC), or 'off'")
                    self.d[key] = [a, b]
            elif key == "market":
                raise ValueError("Use /market forex  or  /market crypto")
            elif key == "paused":
                self.d[key] = raw.lower() in ("1", "true", "yes", "on")
            else:
                raise ValueError(f"Unknown setting '{key}'. Valid: " +
                                 ", ".join(list(SCHEMA) + ["strategy", "timeframe", "symbols", "hours", "paused"]))
            self.save()
            return f"✅ {key} = {self.d[key]}"
