import sqlite3, threading
from datetime import datetime, timezone

SCHEMA = """CREATE TABLE IF NOT EXISTS trades(
 id INTEGER PRIMARY KEY AUTOINCREMENT, ticket INTEGER UNIQUE, symbol TEXT, side TEXT, lots REAL,
 entry REAL, sl REAL, tp REAL, sl_initial REAL, strategy TEXT, opened_at TEXT,
 status TEXT DEFAULT 'open', close_price REAL, closed_at TEXT, profit REAL, reason TEXT)"""


def utcnow_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


class Storage:
    def __init__(self, path):
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._q(SCHEMA)

    def _q(self, sql, args=()):
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    def add_trade(self, ticket, symbol, side, lots, entry, sl, tp, strategy, opened_at=None):
        self._q("INSERT OR REPLACE INTO trades(ticket,symbol,side,lots,entry,sl,tp,sl_initial,strategy,opened_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?)",
                (ticket, symbol, side, lots, entry, sl, tp, sl, strategy, opened_at or utcnow_iso()))

    def open_trades(self):
        return [dict(r) for r in self._q("SELECT * FROM trades WHERE status='open' ORDER BY id").fetchall()]

    def close_trade(self, ticket, price, profit, reason, closed_at=None):
        self._q("UPDATE trades SET status='closed', close_price=?, profit=?, reason=?, closed_at=? WHERE ticket=?",
                (price, profit, reason, closed_at or utcnow_iso(), ticket))

    def update_sl(self, ticket, sl):
        self._q("UPDATE trades SET sl=? WHERE ticket=?", (sl, ticket))

    def recent_closed(self, n=10):
        return [dict(r) for r in self._q(
            "SELECT * FROM trades WHERE status='closed' ORDER BY closed_at DESC, id DESC LIMIT ?", (n,)).fetchall()]

    def opened_since(self, since):
        return self._q("SELECT COUNT(*) FROM trades WHERE opened_at>=?", (since,)).fetchone()[0]

    def realized_since(self, since):
        return self._q("SELECT COALESCE(SUM(profit),0) FROM trades WHERE status='closed' AND closed_at>=?",
                       (since,)).fetchone()[0]

    def stats(self, since=None):
        sql, args = "SELECT profit FROM trades WHERE status='closed'", ()
        if since:
            sql, args = sql + " AND closed_at>=?", (since,)
        p = [r[0] or 0 for r in self._q(sql, args).fetchall()]
        wins, losses = [x for x in p if x > 0], [x for x in p if x <= 0]
        return {"trades": len(p), "wins": len(wins), "losses": len(losses), "pnl": sum(p),
                "win_rate": 100 * len(wins) / len(p) if p else 0.0,
                "profit_factor": (sum(wins) / -sum(losses)) if losses and sum(losses) < 0 else None,
                "best": max(p) if p else 0.0, "worst": min(p) if p else 0.0}
