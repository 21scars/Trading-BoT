import pandas as pd


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def atr(df, n=14):
    pc = df["close"].shift(1)
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()          # Wilder smoothing


def rsi(s, n=14):
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, 1e-12))


def add_indicators(df, atr_period=14):
    df = df.copy()
    df["ema5"], df["ema8"], df["ema50"] = ema(df["close"], 5), ema(df["close"], 8), ema(df["close"], 50)
    df["atr"] = atr(df, atr_period)
    df["rsi"] = rsi(df["close"], 14)
    return df
