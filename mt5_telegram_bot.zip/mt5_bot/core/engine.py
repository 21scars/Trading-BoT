"""Trading engine. tick() is called every few seconds and returns a list of Telegram messages."""
import logging, threading
from datetime import datetime, timezone

from core.indicators import add_indicators
from core.risk import build_levels, calc_lots
from core.strategies import STRATEGIES

log = logging.getLogger("engine")


class Engine:
    def __init__(self, cfg, broker, db, env, clock=None):
        self.cfg, self.broker, self.db, self.env = cfg, broker, db, env
        self.now = clock or (lambda: datetime.now(timezone.utc))
        self.lock = threading.RLock()
        self.last_candle, self._last_err, self._missing = {}, {}, {}

    def today_start(self):
        return self.now().strftime("%Y-%m-%dT00:00:00")

    # ------------------------------------------------------------------ main loop step
    def tick(self):
        msgs = []
        with self.lock:
            self.broker.ensure_connected()
            msgs += self._sync_closed()
            msgs += self._manage_positions()
            if self.cfg.paused:
                return msgs
            for sym in self.cfg.symbols:
                try:
                    msgs += self._process_symbol(sym)
                    self._last_err.pop(sym, None)
                except Exception as e:
                    log.exception("symbol %s failed", sym)
                    if self._last_err.get(sym) != str(e):          # don't repeat the same error every tick
                        self._last_err[sym] = str(e)
                        msgs.append(f"⚠️ {sym}: {e}")
        return msgs

    def _process_symbol(self, sym):
        df = self.broker.candles(sym, self.cfg.timeframe, 300)
        t = df.time.iloc[-1]
        prev, self.last_candle[sym] = self.last_candle.get(sym), t
        if prev is None or prev == t:                              # first look, or no new closed candle yet
            return []
        return self._evaluate(sym, df)

    # ------------------------------------------------------------------ signal -> order
    def _evaluate(self, sym, df):
        cfg = self.cfg
        df = add_indicators(df, cfg.atr_period)
        side = STRATEGIES[cfg.strategy](df, len(df) - 1)
        if not side:
            return []
        reason = self._guard(sym)
        if reason:
            return [f"⏭ {sym} {side.upper()} signal skipped: {reason}"]
        info, (bid, ask) = self.broker.symbol_info(sym), self.broker.price(sym)
        spread_pts = (ask - bid) / info["point"]
        if cfg.max_spread_points and spread_pts > cfg.max_spread_points:
            return [f"⏭ {sym} {side.upper()} signal skipped: spread {spread_pts:.0f} pts > {cfg.max_spread_points}"]
        entry = ask if side == "buy" else bid
        sl, tp, dist = build_levels(side, entry, df.atr.iloc[-1], cfg, info)
        if (ask - bid) > dist * cfg.max_spread_stop_pct / 100:
            return [f"⏭ {sym} {side.upper()} signal skipped: spread is {100 * (ask - bid) / dist:.0f}% of the stop "
                    f"(limit {cfg.max_spread_stop_pct:.0f}%)"]
        acct = self.broker.account()
        lots = calc_lots(acct["balance"], cfg.risk_pct, dist, info)
        if lots <= 0:
            return [f"⏭ {sym} {side.upper()} signal skipped: {cfg.risk_pct}% risk is below the broker's minimum lot"]
        res = self.broker.market_order(sym, side, lots, sl, tp, cfg.magic)
        res["price"] = round(res["price"], info["digits"])
        self.db.add_trade(res["ticket"], sym, side, lots, res["price"], sl, tp, cfg.strategy,
                          self.now().strftime("%Y-%m-%dT%H:%M:%S"))
        risk_money = acct["balance"] * cfg.risk_pct / 100
        return [f"{'📈' if side == 'buy' else '📉'} {side.upper()} {sym} {lots} lots @ {res['price']}\n"
                f"SL {sl} • TP {tp}\nRisk {cfg.risk_pct}% (~{risk_money:.2f} {acct['currency']}) • {cfg.strategy}"]

    def _guard(self, sym):
        cfg = self.cfg
        if not self.broker.trading_allowed():
            return "AutoTrading is OFF in MT5 (turn on the Algo Trading button)"
        acct = self.broker.account()
        if not acct["is_demo"] and not self.env.ALLOW_LIVE:
            return "live account blocked (set ALLOW_LIVE=YES in .env to trade real money)"
        if cfg.trade_hours:
            h = self.now().hour
            if not cfg.trade_hours[0] <= h < cfg.trade_hours[1]:
                return f"outside trading hours {cfg.trade_hours[0]}-{cfg.trade_hours[1]} UTC"
        mine = self.broker.positions(cfg.magic)
        if len(mine) >= cfg.max_open_trades:
            return "max open trades reached"
        if any(p["symbol"] == sym for p in mine):
            return f"{sym} already has an open trade"
        since = self.today_start()
        if self.db.opened_since(since) >= cfg.max_daily_trades:
            return "daily trade limit reached"
        if self.db.realized_since(since) <= -(acct["balance"] * cfg.max_daily_loss_pct / 100):
            return "daily loss limit reached"
        return None

    # ------------------------------------------------------------------ bookkeeping
    def _sync_closed(self):
        """Server-side SL/TP hits happen without the bot: detect them via deal history."""
        msgs, open_db = [], self.db.open_trades()
        if not open_db:
            return msgs
        live = {p["ticket"] for p in self.broker.positions(self.cfg.magic)}
        for t in open_db:
            if t["ticket"] in live:
                continue
            deal = self.broker.closing_deal(t["ticket"])
            if deal is None:
                self._missing[t["ticket"]] = self._missing.get(t["ticket"], 0) + 1
                if self._missing[t["ticket"]] < 60:                # wait up to ~5 min for history to appear
                    continue
                deal = {"price": t["entry"], "profit": 0.0, "reason": "unknown"}
            self.db.close_trade(t["ticket"], deal["price"], deal["profit"], deal["reason"],
                                self.now().strftime("%Y-%m-%dT%H:%M:%S"))
            ccy = self.broker.account()["currency"]
            msgs.append(f"{'✅' if deal['profit'] >= 0 else '❌'} {deal['reason']} • {t['symbol']} {t['side'].upper()} "
                        f"{t['lots']} lots\n{t['entry']} → {deal['price']}\nP/L {deal['profit']:+.2f} {ccy}")
        return msgs

    def _manage_positions(self):
        """Move SL to entry once price has moved breakeven_r x initial risk in our favour."""
        cfg, msgs = self.cfg, []
        if cfg.breakeven_r <= 0:
            return msgs
        live = {p["ticket"]: p for p in self.broker.positions(cfg.magic)}
        for t in self.db.open_trades():
            p = live.get(t["ticket"])
            if not p:
                continue
            risk = abs(t["entry"] - t["sl_initial"])
            if risk <= 0:
                continue
            info = self.broker.symbol_info(t["symbol"])
            buy, tol = t["side"] == "buy", info["point"] * 0.5
            gain = (p["price"] - t["entry"]) if buy else (t["entry"] - p["price"])
            done = (p["sl"] >= t["entry"] - tol) if buy else (0 < p["sl"] <= t["entry"] + tol)
            if gain >= cfg.breakeven_r * risk and not done:
                new_sl = round(t["entry"], info["digits"])
                self.broker.modify_sltp(t["ticket"], t["symbol"], new_sl, p["tp"])
                self.db.update_sl(t["ticket"], new_sl)
                msgs.append(f"🔒 {t['symbol']} {t['side'].upper()}: stop moved to breakeven ({new_sl})")
        return msgs

    # ------------------------------------------------------------------ commands from Telegram
    def close_all(self):
        with self.lock:
            n = 0
            for p in self.broker.positions(self.cfg.magic):
                self.broker.close_position(p)
                n += 1
            return n

    def close_symbol(self, sym):
        with self.lock:
            n = 0
            for p in self.broker.positions(self.cfg.magic):
                if p["symbol"].lower() == sym.lower():
                    self.broker.close_position(p)
                    n += 1
            return n
