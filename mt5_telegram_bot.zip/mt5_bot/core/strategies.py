"""Every strategy: f(df, i) -> "buy" | "sell" | None, where i = latest CLOSED candle.
Live trading and backtesting share this code, so there is no look-ahead.
To add a strategy: write a function and register it in STRATEGIES."""


def engulfing(df, i):
    if i < 1:
        return None
    p, c, trend = df.iloc[i - 1], df.iloc[i], df.ema50.iloc[i]
    if p.close < p.open and c.close > c.open and c.close > p.open and c.open <= p.close and c.close > trend:
        return "buy"
    if p.close > p.open and c.close < c.open and c.close < p.open and c.open >= p.close and c.close < trend:
        return "sell"
    return None


def ema_cross(df, i):
    if i < 1:
        return None
    a0, b0, a1, b1 = df.ema5.iloc[i - 1], df.ema8.iloc[i - 1], df.ema5.iloc[i], df.ema8.iloc[i]
    if a0 <= b0 and a1 > b1:
        return "buy"
    if a0 >= b0 and a1 < b1:
        return "sell"
    return None


def rsi_reversal(df, i):
    if i < 1:
        return None
    r0, r1 = df.rsi.iloc[i - 1], df.rsi.iloc[i]
    if r0 < 30 <= r1:
        return "buy"
    if r0 > 70 >= r1:
        return "sell"
    return None


STRATEGIES = {"engulfing": engulfing, "ema_cross": ema_cross, "rsi_reversal": rsi_reversal}
