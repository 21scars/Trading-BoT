"""Thin wrapper around the official MetaTrader5 Python package (Windows + MT5 terminal required)."""
import threading
import pandas as pd


class MT5Error(Exception):
    pass


class MT5Client:
    def __init__(self, env, mt5=None):
        if mt5 is None:
            try:
                import MetaTrader5 as mt5
            except ImportError:
                raise MT5Error("MetaTrader5 package missing. It only installs on Windows: pip install MetaTrader5")
        self.mt5, self.env, self.lock = mt5, env, threading.RLock()

    # ---- connection ----
    def connect(self):
        with self.lock:
            kw = {}
            if self.env.MT5_PATH:
                kw["path"] = self.env.MT5_PATH
            if self.env.MT5_LOGIN:
                kw.update(login=self.env.MT5_LOGIN, password=self.env.MT5_PASSWORD, server=self.env.MT5_SERVER)
            if not self.mt5.initialize(**kw):
                raise MT5Error(f"MT5 initialize failed: {self.mt5.last_error()}")
            if self.mt5.account_info() is None:
                raise MT5Error(f"No account logged in: {self.mt5.last_error()}")
            return self.account()

    def shutdown(self):
        with self.lock:
            self.mt5.shutdown()

    def ensure_connected(self):
        with self.lock:
            ti = self.mt5.terminal_info()
            if ti is None or not ti.connected:
                self.mt5.shutdown()
                self.connect()

    def trading_allowed(self):
        with self.lock:
            ti, ai = self.mt5.terminal_info(), self.mt5.account_info()
            return bool(ti and ai and ti.trade_allowed and ai.trade_allowed)

    # ---- account / market data ----
    def account(self):
        with self.lock:
            a = self.mt5.account_info()
            if a is None:
                raise MT5Error(f"account_info failed: {self.mt5.last_error()}")
            return {"login": a.login, "name": a.name, "server": a.server, "currency": a.currency,
                    "balance": a.balance, "equity": a.equity, "margin": a.margin,
                    "free_margin": a.margin_free, "profit": a.profit, "leverage": a.leverage,
                    "is_demo": a.trade_mode == self.mt5.ACCOUNT_TRADE_MODE_DEMO}

    def symbol_info(self, symbol):
        with self.lock:
            m = self.mt5
            si = m.symbol_info(symbol)
            if si is None or not si.visible:
                if not m.symbol_select(symbol, True):
                    raise MT5Error(f"Symbol '{symbol}' not found at your broker (check exact name/suffix)")
                si = m.symbol_info(symbol)
                if si is None:
                    raise MT5Error(f"Symbol '{symbol}' unavailable")
            return {"name": si.name, "point": si.point, "digits": si.digits,
                    "tick_size": si.trade_tick_size, "tick_value": si.trade_tick_value,
                    "volume_min": si.volume_min, "volume_max": si.volume_max, "volume_step": si.volume_step,
                    "stops_level": si.trade_stops_level, "spread": si.spread}

    def find_symbols(self, text, limit=25):
        """Search the broker's symbol list (names differ per broker, e.g. BTCUSD / BTCUSDm / BTCUSD.a)."""
        with self.lock:
            allsyms = self.mt5.symbols_get() or []
            return [s.name for s in allsyms if text.lower() in s.name.lower()][:limit]

    def price(self, symbol):
        with self.lock:
            t = self.mt5.symbol_info_tick(symbol)
            if t is None:
                raise MT5Error(f"No tick for {symbol}: {self.mt5.last_error()}")
            return float(t.bid), float(t.ask)

    def candles(self, symbol, timeframe, count=300):
        """Closed candles only (the forming candle is dropped)."""
        with self.lock:
            self.symbol_info(symbol)
            tf = getattr(self.mt5, f"TIMEFRAME_{timeframe}")
            rates = self.mt5.copy_rates_from_pos(symbol, tf, 0, count + 1)
            if rates is None or len(rates) < 2:
                raise MT5Error(f"No candles for {symbol} {timeframe}: {self.mt5.last_error()}")
            df = pd.DataFrame(rates)
            df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
            df = df.rename(columns={"tick_volume": "volume"})
            return df[["time", "open", "high", "low", "close", "volume"]].iloc[:-1].reset_index(drop=True)

    # ---- positions ----
    def positions(self, magic=None):
        with self.lock:
            m = self.mt5
            raw = m.positions_get()
            if raw is None:
                code = m.last_error()[0]
                if code != 1:                                   # 1 = success -> simply no positions
                    raise MT5Error(f"positions_get failed: {m.last_error()}")
                raw = []
            out = []
            for p in raw:
                if magic is not None and p.magic != magic:
                    continue
                out.append({"ticket": p.ticket, "symbol": p.symbol,
                            "side": "buy" if p.type == m.POSITION_TYPE_BUY else "sell",
                            "lots": p.volume, "entry": p.price_open, "sl": p.sl, "tp": p.tp,
                            "price": p.price_current, "profit": p.profit + getattr(p, "swap", 0.0),
                            "magic": p.magic})
            return out

    # ---- orders ----
    def _send(self, req):
        m, last = self.mt5, None
        invalid_fill = getattr(m, "TRADE_RETCODE_INVALID_FILL", 10030)
        for fill in (m.ORDER_FILLING_IOC, m.ORDER_FILLING_FOK, m.ORDER_FILLING_RETURN):
            r = m.order_send({**req, "type_filling": fill})
            if r is None:
                raise MT5Error(f"order_send returned None: {m.last_error()}")
            if r.retcode == m.TRADE_RETCODE_DONE:
                return r
            last = r
            if r.retcode != invalid_fill:                       # only retry on unsupported filling mode
                break
        raise MT5Error(f"Order rejected (retcode {last.retcode}): {last.comment}")

    def market_order(self, symbol, side, lots, sl, tp, magic, comment="mt5bot"):
        with self.lock:
            m = self.mt5
            bid, ask = self.price(symbol)
            r = self._send({"action": m.TRADE_ACTION_DEAL, "symbol": symbol, "volume": lots,
                            "type": m.ORDER_TYPE_BUY if side == "buy" else m.ORDER_TYPE_SELL,
                            "price": ask if side == "buy" else bid, "sl": sl, "tp": tp, "deviation": 20,
                            "magic": magic, "comment": comment, "type_time": m.ORDER_TIME_GTC})
            mine = [p for p in self.positions(magic) if p["symbol"] == symbol]
            pos = next((p for p in mine if p["ticket"] == r.order), None) or (mine[-1] if mine else None)
            return {"ticket": pos["ticket"] if pos else r.order,
                    "price": pos["entry"] if pos else r.price, "lots": lots}

    def close_position(self, pos):
        with self.lock:
            m = self.mt5
            bid, ask = self.price(pos["symbol"])
            buy = pos["side"] == "buy"
            return self._send({"action": m.TRADE_ACTION_DEAL, "symbol": pos["symbol"], "volume": pos["lots"],
                               "type": m.ORDER_TYPE_SELL if buy else m.ORDER_TYPE_BUY,
                               "position": pos["ticket"], "price": bid if buy else ask, "deviation": 20,
                               "magic": pos["magic"], "comment": "mt5bot close", "type_time": m.ORDER_TIME_GTC})

    def modify_sltp(self, ticket, symbol, sl, tp):
        with self.lock:
            m = self.mt5
            r = m.order_send({"action": m.TRADE_ACTION_SLTP, "position": ticket, "symbol": symbol,
                              "sl": sl, "tp": tp})
            if r is None or r.retcode != m.TRADE_RETCODE_DONE:
                raise MT5Error(f"SL/TP modify failed: {getattr(r, 'retcode', None)} {getattr(r, 'comment', '')}")

    def closing_deal(self, ticket):
        """Result of a closed position from deal history (profit incl. commission+swap, price, reason)."""
        with self.lock:
            m = self.mt5
            deals = m.history_deals_get(position=ticket)
            if not deals:
                return None
            outs = [d for d in deals if d.entry in (m.DEAL_ENTRY_OUT, getattr(m, "DEAL_ENTRY_OUT_BY", -1),
                                                     getattr(m, "DEAL_ENTRY_INOUT", -1))]
            if not outs:
                return None
            total = sum(d.profit + getattr(d, "commission", 0.0) + getattr(d, "swap", 0.0) +
                        getattr(d, "fee", 0.0) for d in deals)
            code = outs[-1].reason
            reason = {getattr(m, "DEAL_REASON_SL", 4): "SL", getattr(m, "DEAL_REASON_TP", 5): "TP",
                      getattr(m, "DEAL_REASON_SO", 6): "stop-out", getattr(m, "DEAL_REASON_EXPERT", 3): "bot close"
                      }.get(code, "manual")
            return {"price": outs[-1].price, "profit": total, "reason": reason}
