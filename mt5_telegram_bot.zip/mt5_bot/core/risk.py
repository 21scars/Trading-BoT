import math


def _decimals(step):
    return max(0, int(round(-math.log10(step))))


def calc_lots(balance, risk_pct, sl_distance, info):
    """Lot size so that hitting the stop loses risk_pct of balance, using the broker's own tick value.
    Returns 0 when the result would be below the broker's minimum lot."""
    loss_per_lot = (sl_distance / info["tick_size"]) * info["tick_value"]
    if loss_per_lot <= 0:
        return 0.0
    raw = (balance * risk_pct / 100) / loss_per_lot
    step = info["volume_step"]
    lots = round(math.floor(raw / step + 1e-9) * step, _decimals(step))
    if lots < info["volume_min"]:
        return 0.0
    return min(lots, info["volume_max"])


def build_levels(side, entry, atr_value, cfg, info):
    """Returns (sl, tp, sl_distance). SL distance respects the broker's minimum stop level."""
    dist = atr_value * cfg.atr_sl_mult
    min_dist = (info["stops_level"] + info["spread"]) * info["point"] * 1.1
    dist = max(dist, min_dist)
    sign = 1 if side == "buy" else -1
    d = info["digits"]
    return round(entry - sign * dist, d), round(entry + sign * dist * cfg.rr, d), dist
