"""Minimal fake of the MetaTrader5 module so the engine can be tested without a terminal."""
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace as NS


class FakeMT5:
    TIMEFRAME_M1, TIMEFRAME_M5, TIMEFRAME_M15, TIMEFRAME_M30, TIMEFRAME_H1, TIMEFRAME_H4, TIMEFRAME_D1 = 1, 5, 15, 30, 60, 240, 1440
    ACCOUNT_TRADE_MODE_DEMO, ACCOUNT_TRADE_MODE_REAL = 0, 2
    ORDER_TYPE_BUY, ORDER_TYPE_SELL = 0, 1
    POSITION_TYPE_BUY, POSITION_TYPE_SELL = 0, 1
    TRADE_ACTION_DEAL, TRADE_ACTION_SLTP = 1, 6
    ORDER_TIME_GTC = 0
    ORDER_FILLING_FOK, ORDER_FILLING_IOC, ORDER_FILLING_RETURN = 0, 1, 2
    TRADE_RETCODE_DONE, TRADE_RETCODE_INVALID_FILL = 10009, 10030
    DEAL_ENTRY_IN, DEAL_ENTRY_OUT = 0, 1
    DEAL_REASON_CLIENT, DEAL_REASON_EXPERT, DEAL_REASON_SL, DEAL_REASON_TP, DEAL_REASON_SO = 0, 3, 4, 5, 6

    def __init__(self, demo=True):
        self.demo, self.balance, self.price, self.spread = demo, 1000.0, 1.10000, 0.00012
        self.closed, self.pos, self.deals, self.next_ticket = [], [], [], 1000
        self.t = datetime(2026, 1, 5, 7, 0, tzinfo=timezone.utc)
        self.fill_reject_ioc = False                      # simulate brokers that reject IOC

    # --- helpers for tests ---
    def advance_candle(self, o, h, l, c):
        self.closed.append({"time": int(self.t.timestamp()), "open": o, "high": h, "low": l, "close": c, "tick_volume": 100})
        self.t += timedelta(minutes=15)
        self.price = c
        for p in self.pos:
            p.price_current = c

    def trigger_exit(self, ticket, reason):
        p = next(x for x in self.pos if x.ticket == ticket)
        px = p.sl if reason == "SL" else p.tp
        sign = 1 if p.type == 0 else -1
        profit = sign * (px - p.price_open) * p.volume * 100000
        self._close(p, px, profit, self.DEAL_REASON_SL if reason == "SL" else self.DEAL_REASON_TP)

    def _close(self, p, px, profit, reason):
        self.pos.remove(p)
        self.balance += profit
        self.deals.append(NS(position=p.ticket, entry=0, profit=0.0, commission=-0.5, swap=0.0, fee=0.0, price=p.price_open, reason=0))
        self.deals.append(NS(position=p.ticket, entry=1, profit=profit, commission=0.0, swap=0.0, fee=0.0, price=px, reason=reason))

    # --- MT5 API ---
    def initialize(self, **kw): return True
    def shutdown(self): pass
    def last_error(self): return (1, "Success")
    def terminal_info(self): return NS(connected=True, trade_allowed=True)
    def account_info(self):
        eq = self.balance + sum(self._pl(p) for p in self.pos)
        return NS(login=555, name="Test", server="Fake-Demo", currency="USD", balance=self.balance, equity=eq,
                  margin=0.0, margin_free=eq, profit=eq - self.balance, leverage=500, trade_allowed=True,
                  trade_mode=self.ACCOUNT_TRADE_MODE_DEMO if self.demo else self.ACCOUNT_TRADE_MODE_REAL)
    def _pl(self, p):
        return (1 if p.type == 0 else -1) * (self.price - p.price_open) * p.volume * 100000
    SYMS = {"EURUSD": dict(point=0.00001, digits=5, trade_tick_size=0.00001, trade_tick_value=1.0, trade_stops_level=10, spread=12),
            "GBPUSD": dict(point=0.00001, digits=5, trade_tick_size=0.00001, trade_tick_value=1.0, trade_stops_level=10, spread=14),
            "BTCUSD": dict(point=0.01, digits=2, trade_tick_size=0.01, trade_tick_value=0.01, trade_stops_level=0, spread=2500),
            "ETHUSD": dict(point=0.01, digits=2, trade_tick_size=0.01, trade_tick_value=0.01, trade_stops_level=0, spread=300)}
    def symbol_select(self, s, v): return s in self.SYMS
    def symbols_get(self, **kw): return [NS(name=n) for n in self.SYMS]
    def symbol_info(self, s):
        if s not in self.SYMS: return None
        return NS(name=s, visible=True, volume_min=0.01, volume_max=100.0, volume_step=0.01, **self.SYMS[s])
    def symbol_info_tick(self, s): return NS(bid=self.price, ask=self.price + self.spread)
    def copy_rates_from_pos(self, s, tf, start, count):
        forming = {"time": int(self.t.timestamp()), "open": self.price, "high": self.price, "low": self.price, "close": self.price, "tick_volume": 1}
        return (self.closed + [forming])[-count:]
    def positions_get(self, **kw): return tuple(self.pos)
    def order_send(self, req):
        if req.get("type_filling") == self.ORDER_FILLING_IOC and self.fill_reject_ioc:
            return NS(retcode=self.TRADE_RETCODE_INVALID_FILL, comment="Unsupported filling mode", order=0, price=0)
        if req["action"] == self.TRADE_ACTION_SLTP:
            p = next(x for x in self.pos if x.ticket == req["position"])
            p.sl, p.tp = req["sl"], req["tp"]
            return NS(retcode=self.TRADE_RETCODE_DONE, comment="ok", order=0, price=0)
        if "position" in req:                                              # closing deal
            p = next(x for x in self.pos if x.ticket == req["position"])
            px = self.price if p.type == 0 else self.price + self.spread
            self._close(p, px, (1 if p.type == 0 else -1) * (px - p.price_open) * p.volume * 100000, self.DEAL_REASON_EXPERT)
            return NS(retcode=self.TRADE_RETCODE_DONE, comment="ok", order=p.ticket, price=px)
        self.next_ticket += 1
        buy = req["type"] == self.ORDER_TYPE_BUY
        px = self.price + self.spread if buy else self.price
        self.pos.append(NS(ticket=self.next_ticket, symbol=req["symbol"], type=0 if buy else 1, volume=req["volume"],
                           price_open=px, sl=req["sl"], tp=req["tp"], price_current=self.price, profit=0.0, swap=0.0,
                           magic=req["magic"]))
        return NS(retcode=self.TRADE_RETCODE_DONE, comment="ok", order=self.next_ticket, price=px)
    def history_deals_get(self, position=None, **kw): return [d for d in self.deals if d.position == position]
