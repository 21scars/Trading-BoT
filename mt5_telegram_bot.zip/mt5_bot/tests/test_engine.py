"""Run:  python tests/test_engine.py   (no MT5, no Telegram, no internet needed)"""
import sys, tempfile
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
from fake_mt5 import FakeMT5
from settings import RuntimeConfig
from core.engine import Engine
from core.indicators import add_indicators
from core.mt5_client import MT5Client
from core.risk import calc_lots
from core.storage import Storage
from core.strategies import STRATEGIES
import telegram_bot.commands as C


def make(demo=True, **cfg_over):
    tmp = Path(tempfile.mkdtemp())
    fake = FakeMT5(demo)
    # 120 gently falling candles (ema5 < ema8), so one big up candle creates a bullish EMA cross
    p = 1.1000
    for _ in range(120):
        o, c = p, p - 0.00004
        fake.advance_candle(o, o + 0.00005, c - 0.00005, c)
        p = c
    cfg = RuntimeConfig(tmp / "c.json")
    for k, v in {"symbols": "EURUSD", "strategy": "ema_cross", "hours": "off", **cfg_over}.items():
        cfg.set(k, v)
    eng = Engine(cfg, MT5Client(NS(MT5_PATH="", MT5_LOGIN=0), mt5=fake), Storage(tmp / "t.db"), NS(ALLOW_LIVE=False))
    return fake, eng


def jump(fake, up=True):
    o, c = fake.price, fake.price + (0.0030 if up else -0.0030)
    fake.advance_candle(o, max(o, c) + 0.0001, min(o, c) - 0.0001, c)


ok = lambda name: print("PASS", name)

# 1. strategy really fires on the crafted data
fake, eng = make()
jump(fake)
df = add_indicators(eng.broker.candles("EURUSD", "M15", 300))
assert STRATEGIES["ema_cross"](df, len(df) - 1) == "buy"; ok("strategy signal")

# 2. lot sizing: $1000 * 0.5% = $5 risk; 150-pip... stop distance 0.0015 => $150/lot => 0.03 lots
info = eng.broker.symbol_info("EURUSD")
assert calc_lots(1000, 0.5, 0.0015, info) == 0.03
assert calc_lots(1000, 0.05, 0.0050, info) == 0.0          # below broker minimum -> skip
ok("lot sizing")

# 3. full cycle: first tick only observes, next candle trades
fake, eng = make()
assert eng.tick() == []
jump(fake)
m = eng.tick()
assert len(fake.pos) == 1 and "BUY EURUSD 0.0" in m[0], m
t = eng.db.open_trades()[0]
assert t["sl"] < t["entry"] < t["tp"] and abs((t["tp"] - t["entry"]) / (t["entry"] - t["sl"]) - 1.5) < 0.05
ok("entry order + db record + SL/TP geometry")

# 4. no duplicate trade while one is open / same candle not re-processed
assert eng.tick() == [] and len(fake.pos) == 1; ok("no duplicate")

# 5. server-side TP hit is detected and reported
fake.trigger_exit(fake.pos[0].ticket, "TP")
m = eng.tick()
assert "TP" in m[0] and "✅" in m[0], m
assert eng.db.open_trades() == [] and eng.db.stats()["wins"] == 1; ok("TP detected + recorded")

# 6. breakeven moves the stop after +1R
fake, eng = make()
eng.tick(); jump(fake); eng.tick()
pos = fake.pos[0]; risk = pos.price_open - pos.sl
fake.advance_candle(fake.price, pos.price_open + risk * 1.2, fake.price, pos.price_open + risk * 1.1)
m = eng.tick()
assert any("breakeven" in x for x in m) and abs(fake.pos[0].sl - pos.price_open) < 1e-5; ok("breakeven")

# 7. guards: paused / max open / live account blocked / daily trade limit
fake, eng = make(); eng.tick(); eng.cfg.set("paused", "true"); jump(fake)
assert eng.tick() == [] and not fake.pos; ok("paused")
fake, eng = make(demo=False); eng.tick(); jump(fake)
m = eng.tick(); assert "live account blocked" in m[0] and not fake.pos; ok("live blocked")
fake, eng = make(max_daily_trades="1"); eng.tick(); jump(fake); eng.tick()
fake.trigger_exit(fake.pos[0].ticket, "SL"); eng.tick()
m = []
for _ in range(3): jump(fake, up=False); m += eng.tick()      # a SELL cross appears, but the daily limit (1) is used up
assert not fake.pos and any("daily trade limit" in x for x in m), m; ok("daily limit")

# 8. broker rejects IOC filling -> client retries with FOK
fake, eng = make(); fake.fill_reject_ioc = True
eng.tick(); jump(fake); eng.tick(); assert len(fake.pos) == 1; ok("fill-mode fallback")

# 9. close all + status/stats texts
fake, eng = make(); eng.tick(); jump(fake); eng.tick()
assert eng.close_all() == 1 and not fake.pos
assert "bot close" in eng.tick()[0]
for fn in (C.status_text, C.balance_text, C.positions_text, C.trades_text, C.stats_text, C.config_text, C.summary_text):
    assert isinstance(fn(eng), str) and fn(eng)
ok("close_all + telegram texts")

# 10. runtime settings validation
assert "risk_pct = 1.0" in C.apply_setting(eng, "risk_pct", "1")
for bad in (("risk_pct", "99"), ("strategy", "nope"), ("timeframe", "M7"), ("symbols", "XXXYYY"), ("hours", "20-7")):
    try: C.apply_setting(eng, *bad); raise SystemExit(f"should have failed: {bad}")
    except Exception as e: assert "should have failed" not in str(e)
ok("settings validation")

# 11. backtest runs on synthetic csv
import pandas as pd, backtest
rng = np.random.default_rng(3); n = 3000
c = 1.1 + np.cumsum(rng.normal(0, 0.0004, n)); o = np.r_[c[0], c[:-1]]
df = pd.DataFrame({"time": pd.date_range("2026-01-01", periods=n, freq="15min"), "open": o,
                   "high": np.maximum(o, c) + 0.0002, "low": np.minimum(o, c) - 0.0002, "close": c})
t = backtest.backtest(df, STRATEGIES["ema_cross"], 1.5, 1.5, 14, 0.00012); assert len(t) > 10; ok("backtest")
# 12. market switching: forex <-> crypto presets, broker-specific names, symbol search
fake, eng = make()
msg = C.apply_market(eng, "crypto")
c = eng.cfg
assert c.market == "crypto" and c.symbols == ["BTCUSD", "ETHUSD"] and c.trade_hours is None
assert c.max_spread_points == 0 and c.atr_sl_mult == 2.0 and "CRYPTO" in msg; ok("switch to crypto")
btc = eng.broker.symbol_info("BTCUSD")           # $10,000 * 0.5% = $50 risk, $400 stop => 0.12 lots
assert calc_lots(10000, 0.5, 400.0, btc) == 0.12; ok("crypto lot sizing")
C.apply_market(eng, "forex")
assert eng.cfg.market == "forex" and eng.cfg.trade_hours == [7, 20] and eng.cfg.symbols == ["EURUSD", "GBPUSD"]; ok("switch back to forex")
assert "Market: FOREX" in C.config_text(eng) and "BTCUSD" in C.find_text(eng, "btc") and "No symbols" in C.find_text(eng, "xyz")
C.apply_market(eng, "crypto", ["BTCUSD", "BTCUSDm"])        # one name exists, one doesn't -> keeps the valid one
assert eng.cfg.symbols == ["BTCUSD"]
for bad in (("crypto", ["NOPE1"]), ("stocks", None)):
    try: C.apply_market(eng, *bad); raise SystemExit("should have failed")
    except ValueError: pass
ok("broker-specific symbols + validation")

# 13. spread-vs-stop rule blocks signals when spread is too wide relative to the stop
fake, eng = make(); fake.spread = 0.00025; eng.tick(); jump(fake)
m = eng.tick(); assert not fake.pos and "of the stop" in m[0], m; ok("spread vs stop rule")
print("\nALL TESTS PASSED")
