"""Backtest the same strategies the bot trades.
  python backtest.py --symbol EURUSD --tf M15 --count 20000      (uses your MT5 terminal)
  python backtest.py --csv EURUSD_M15.csv --point 0.00001         (offline; columns time,open,high,low,close)"""
import argparse
import pandas as pd
from core.indicators import add_indicators
from core.strategies import STRATEGIES
from settings import DEFAULTS


def backtest(df, strategy, atr_mult, rr, atr_period, cost, warmup=60):
    df, trades, i, n = add_indicators(df, atr_period), [], warmup, len(df)
    while i < n - 2:
        side = strategy(df, i)
        if not side:
            i += 1
            continue
        sign = 1 if side == "buy" else -1
        entry, dist = df.open.iloc[i + 1], df.atr.iloc[i] * atr_mult      # enter at next candle's open
        sl, tp, exit_px, j = entry - sign * dist, entry + sign * dist * rr, None, i + 1
        for j in range(i + 1, n):
            hi, lo = df.high.iloc[j], df.low.iloc[j]
            if (lo <= sl) if sign == 1 else (hi >= sl):
                exit_px = sl
                break                                                      # same-candle clash => stop first
            if (hi >= tp) if sign == 1 else (lo <= tp):
                exit_px = tp
                break
        if exit_px is None:
            break
        trades.append({"time": df.time.iloc[i + 1], "side": side, "R": (sign * (exit_px - entry) - cost) / dist})
        i = j + 1
    return pd.DataFrame(trades)


def report(t, name, risk_pct):
    if t.empty:
        return print(f"{name:13s} no trades")
    wins, losses = t[t.R > 0].R.sum(), -t[t.R <= 0].R.sum()
    curve = t.R.cumsum()
    print(f"{name:13s} trades={len(t):4d} win%={100 * (t.R > 0).mean():5.1f} avgR={t.R.mean():+.2f} "
          f"totalR={t.R.sum():+.1f} PF={wins / losses if losses else float('inf'):.2f} "
          f"maxDD={(curve.cummax() - curve).max():.1f}R  ≈return {t.R.sum() * risk_pct:+.1f}% at {risk_pct}% risk")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbol", default=DEFAULTS["symbols"][0])
    ap.add_argument("--tf", default=DEFAULTS["timeframe"])
    ap.add_argument("--count", type=int, default=20000)
    ap.add_argument("--strategy", default="all")
    ap.add_argument("--csv", default="")
    ap.add_argument("--point", type=float, default=0.00001)
    ap.add_argument("--spread", type=float, default=12, help="spread in points")
    a = ap.parse_args()
    if a.csv:
        data, point = pd.read_csv(a.csv, parse_dates=["time"]), a.point
    else:
        from core.mt5_client import MT5Client
        from settings import Env
        broker = MT5Client(Env)
        broker.connect()
        data, point = broker.candles(a.symbol, a.tf, a.count), broker.symbol_info(a.symbol)["point"]
        broker.shutdown()
    for name, fn in STRATEGIES.items():
        if a.strategy in ("all", name):
            t = backtest(data, fn, DEFAULTS["atr_sl_mult"], DEFAULTS["rr"], DEFAULTS["atr_period"], a.spread * point)
            report(t, name, DEFAULTS["risk_pct"])
