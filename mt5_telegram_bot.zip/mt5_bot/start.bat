@echo off
REM Auto-restart wrapper: keeps the bot alive if it ever exits.
:loop
python main.py
echo Bot stopped. Restarting in 10 seconds (close this window to quit)...
timeout /t 10 /nobreak >nul
goto loop
