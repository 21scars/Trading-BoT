# MT5 Telegram Trading Bot

A full automated trading project: connects to **your MetaTrader 5 account**, trades by itself, and is controlled
and monitored from **Telegram**.

```
main.py                  entry point
settings.py              .env credentials + live-editable settings (data/config.json)
core/
  mt5_client.py          MT5 connection: candles, account, positions, orders, deal history
  engine.py              signal -> risk checks -> order -> breakeven -> close detection
  strategies.py          engulfing, ema_cross, rsi_reversal (add your own here)
  risk.py                lot sizing from broker tick value, SL/TP levels
  storage.py             SQLite trade history (data/trades.db)
telegram_bot/
  bot.py                 commands, buttons, background jobs, chat-id lock
  commands.py            status / stats / settings texts
backtest.py              test strategies on MT5 history or a CSV
tests/                   fake-MT5 test suite (python tests/test_engine.py)
start.bat                auto-restart wrapper for Windows / VPS
```

## Setup (Windows)
1. Install **MetaTrader 5** from your broker, log in to a **DEMO** account, and turn on **Algo Trading** (toolbar button).
2. Install Python 3.10+, then in this folder: `pip install -r requirements.txt`
3. In Telegram: talk to **@BotFather** -> `/newbot` -> copy the token. Talk to **@userinfobot** to get your chat id.
4. Copy `.env.example` to `.env` and fill in the MT5 login, Telegram token and chat id.
5. `python backtest.py --symbol EURUSD --tf M15 --count 20000` and look at the results first.
6. `python main.py` (or `start.bat` to auto-restart). The bot messages you "Bot online". Send `/help`.

Symbol names differ per broker (e.g. `EURUSD.m`). Use exactly what your Market Watch shows: `/symbols EURUSD.m`.

## Choosing the market: Forex or Crypto
Send `/market` and tap **Forex** or **Crypto**. Each is a preset (symbols, timeframe, stop size, spread rules, trading hours):

| | Forex | Crypto (broker CFDs, e.g. BTCUSD) |
|---|---|---|
| Symbols | EURUSD, GBPUSD | BTCUSD, ETHUSD |
| Stop | 1.5 x ATR | 2.0 x ATR (wider, crypto is more volatile) |
| Hours | 07:00-20:00 UTC | 24/7 |
| Spread rule | max 30 points + 25% of stop | 25% of stop |

- Broker names differ (`BTCUSDm`, `BTCUSD.a`...). Use `/find btc` to see your broker's exact names, then
  `/market crypto BTCUSDm,ETHUSDm`. Any symbol your broker offers works: `/symbols USDJPY,XAUUSD`.
- After choosing a market you can still change anything: `/risk`, `/timeframe`, `/set rr 2`, `/set hours 8-17`.
- Backtest either market: `python backtest.py --symbol BTCUSD --tf M15`.
- Crypto here means your broker's crypto **CFDs inside MT5**, not coins on an exchange. Brokers often have a larger
  minimum lot on crypto, so a small balance may be skipped with a "below the broker's minimum lot" message.

## Telegram commands
| Command | What it does |
|---|---|
| `/status` `/balance` `/positions` `/trades` `/stats` | account, open trades, history, performance |
| `/pause` `/resume` | stop / start opening new trades |
| `/close EURUSD` `/closeall` | close trades (closeall asks to confirm) |
| `/strategy` `/risk 0.5` `/symbols` `/timeframe M15` | change settings live |
| `/set rr 2` `/set hours 7-20` ... | rr, atr_sl_mult, breakeven_r, max_open_trades, max_daily_trades, max_daily_loss_pct, max_spread_points |
| `/market` `/find btc` | switch Forex / Crypto, search your broker's symbols |
| `/menu` | button menu |

You also get automatic alerts for every entry, exit (TP/SL/manual), breakeven move, skipped signal, error, and a
daily summary. Only chat ids listed in `TELEGRAM_CHAT_ID` can control the bot.

## Safety built in
- **Real accounts are blocked** until you set `ALLOW_LIVE=YES` in `.env`.
- Every trade has a stop loss and take profit set on the broker's server, so they work even if the bot is offline.
- Position size comes from your balance and the stop distance (default 0.5% risk per trade).
- Limits: max open trades, max trades per day, daily loss limit, max spread, trading hours (UTC).
- One trade per symbol, the first candle after start-up is never traded, same candle is never traded twice.
- Auto-reconnect to MT5; errors are reported to Telegram once, not spammed.

## Important
- The official MetaTrader5 Python package works with **MT5 only, on Windows**. It does **not** work with MT4. If your
  broker only offers MT4, open an MT5 account with them or use a bridge EA (not included).
- The MT5 terminal must stay running (use a Windows VPS for 24/7).
- This was tested with a simulated MT5, not a live terminal. **Run it on a demo account for several weeks** and
  compare it with the backtest before considering real money. No strategy here is guaranteed to be profitable.
